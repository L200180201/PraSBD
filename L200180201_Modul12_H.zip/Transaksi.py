from tkinter import *
import mysql.connector
import csv
from tkinter import ttk

root = Tk()
root.title('PERHOTELAN')
root.geometry('450x380')

#Connect ke DB MySQL
mydb = mysql.connector.connect(
				user='root', 
				database='perhotelan'
			)

# Check to see if connection to MySQL was created
# print(mydb)

# Create a cursor and initialize it
my_cursor = mydb.cursor()

# Clear Text Fields
def clear_fields():
	no_transaksi_box.delete(0, END)
	booking_box.delete(0, END)
	check_in_box.delete(0, END)
	check_out_box.delete(0, END)

# Submit Transaksi To Database
def add_Transaksi():
	sql_command = "INSERT INTO Transaksi (no_transaksi, booking, check_in, check_out) VALUES (%s, %s, %s, %s)"
	values = (no_transaksi_box.get(), booking_box.get(), check_in_box.get(), check_out_box.get())
	my_cursor.execute(sql_command, values)

	# Commit the changes to the database
	mydb.commit()
	# Clear the fields
	clear_fields()

# Write To CSV Excel Function
def write_to_csv(result):
	with open('Transaksi.csv', 'a', newline='') as f:
		w = csv.writer(f, dialect='excel')
		for record in result:
			w.writerow(record)

# Edit Transaksi
def edit_Transaksi():
	edit_Transaksi = Tk()
	edit_Transaksi.title("Edit Transaksi")
	edit_Transaksi.geometry("1000x600")

	def update():
	
		sql_command = """UPDATE Transaksi SET booking = %s, check_in = %s, check_out = %s WHERE no_transaksi = %s""" 

		booking = booking_box1.get()
		check_in = check_in_box1.get()
		check_out = check_out_box1.get()
		no_transaksi = no_transaksi_box1.get()

		input = (booking, check_in, check_out,no_transaksi)
		my_cursor.execute(sql_command, input)

		# Commit the changes to the database
		mydb.commit()
		# Clear the fields
		edit_Transaksi.destroy()
		
	def edit_now(id, index):
		sql2 = "SELECT * FROM Transaksi WHERE no_transaksi = %s"
		name2 = (id, )
		results = my_cursor.execute(sql2, name2)
		results = my_cursor.fetchall()
		print(results)

		#fart = Label(edit_Transaksi, text=id)
		#fart.grid(row=10, column=1)
		#Create Main Form To Enter Customer Data
		no_transaksi_label = Label(edit_Transaksi, text="No Transaksi").grid(row=index+2, column=0, sticky=W, padx=10)
		booking_label = Label(edit_Transaksi, text="Booking ").grid(row=index+3, column=0, sticky=W, padx=10)
		check_in_label = Label(edit_Transaksi, text="Check in").grid(row=index+4, column=0, sticky=W, padx=10)
		check_out_label = Label(edit_Transaksi, text="Check out").grid(row=index+5, column=0, sticky=W, padx=10)

		global no_transaksi_box1
		no_transaksi_box1 = Entry(edit_Transaksi)
		no_transaksi_box1.insert(0, results[0][0])
		no_transaksi_box1.grid(row=index+2, column=1)

		global booking_box1
		booking_box1 = Entry(edit_Transaksi)
		booking_box1.grid(row=index+3, column=1, pady=5)
		booking_box1.insert(0, results[0][1])

		global check_in_box1
		check_in_box1 = Entry(edit_Transaksi)
		check_in_box1.grid(row=index+4, column=1, pady=5)
		check_in_box1.insert(0, results[0][2])

		global check_out_box1
		check_out_box1 = Entry(edit_Transaksi)
		check_out_box1.grid(row=index+5, column=1, pady=5)
		check_out_box1.insert(0, results[0][3])

		edit_record = Button(edit_Transaksi, text="Save Record", command=update)
		edit_record.grid(row=index+6, column=0, padx=10)
		

	def search_now():
		selected = drop.get()
		sql = ""
		if selected == "Search by...":
			test = Label(edit_Transaksi, text="Hey! Kamu Lupa memilih drop down selection")
			test.grid(row=2, column=0)
		if selected == "Booking ":
			sql = "SELECT * FROM Transaksi WHERE booking = %s"
			
		if selected == "Check in":
			sql = "SELECT * FROM Transaksi WHERE check_in = %s"
			
		if selected == "Check out":
			sql = "SELECT * FROM Transaksi WHERE check_out = %s"

		if selected == "No transaksi":
			sql = "SELECT * FROM Transaksi WHERE no_transaksi = %s"
			
		searched = search_box.get()
		#sql = "SELECT * FROM Transaksi WHERE last_name = %s"
		name = (searched, )
		result = my_cursor.execute(sql, name)
		result = my_cursor.fetchall()

		if not result: 
			result = "Record Not Found..."
			searched_label = Label(edit_Transaksi, text=result)
			searched_label.grid(row=2, column=0)

		else:
			no_transaksi_label2 = Label(edit_Transaksi, text="             No transaksi").grid(row=2, column=1, sticky=W, padx=10)
			booking_label2 = Label(edit_Transaksi, text="              Booking").grid(row=2, column=2, sticky=W, padx=10)
			check_in_label2 = Label(edit_Transaksi, text="Check in").grid(row=2, column=3, sticky=W, padx=10)
			check_out_label2 = Label(edit_Transaksi, text="Check out").grid(row=2, column=4, sticky=W, padx=10)
			for index, x in enumerate(result):
				num = 0
				index += 2
				stuff = str(x[0])
				edit_button = Button(edit_Transaksi, text="Edit " + stuff, command=lambda: edit_now(stuff, index))
				edit_button.grid(row=index+1, column=num)
				for y in x:
					searched_label = Label(edit_Transaksi, text=y)
					searched_label.grid(row=index+1, column=num+1)
					num +=1
			 
			
	# Entry box to search for customer
	search_box = Entry(edit_Transaksi)
	search_box.grid(row=0, column=1, padx=10, pady=10)
	# Entry box Label search for customer
	search_box_label = Label(edit_Transaksi, text="Search Transaksi ")
	search_box_label.grid(row=0, column=0, padx=10, pady=10)
	# Entry box search  Button for customer
	search_button = Button(edit_Transaksi, text="Search Transaksi", command=search_now)
	search_button.grid(row=1, column=0, padx=10)
	# Drop Down Box
	drop = ttk.Combobox(edit_Transaksi, value=["Search by...", "Booking","Check in", "Check out", "No transaksi"])
	drop.current(0)
	drop.grid(row=0, column=2)


# Search Transaksi
def search_Transaksi():
	search_Transaksi = Tk()
	search_Transaksi.title("Search Transaksi")
	search_Transaksi.geometry("1000x600")

	def search_now():
		selected = drop.get()
		sql = ""
		if selected == "Search by...":
			test = Label(search_Transaksi, text="Hey! Kamu Lupa memilih drop down selection")
			test.grid(row=2, column=0)
		if selected == "Booking":
			sql = "SELECT * FROM Transaksi WHERE booking = %s"
			
		if selected == "Check in":
			sql = "SELECT * FROM Transaksi WHERE check_in = %s"
			
		if selected == "Check out":
			sql = "SELECT * FROM Transaksi WHERE check_out = %s"

		if selected == "No transaksi":
			sql = "SELECT * FROM Transaksi WHERE no_transaksi = %s"
			
		
		searched = search_box.get()
		#sql = "SELECT * FROM Transaksi WHERE last_name = %s"
		name = (searched, )
		result = my_cursor.execute(sql, name)
		result = my_cursor.fetchall()

		if not result: 
			result = "Record Not Found..."
			searched_label = Label(search_Transaksi, text=result)
			searched_label.grid(row=2, column=0)

		else:
			no_transaksi_label2 = Label(search_Transaksi, text="    No transaksi").grid(row=2, column=0, sticky=W, padx=10)
			booking_label2 = Label(search_Transaksi, text="              Booking").grid(row=2, column=1, sticky=W, padx=10)
			check_in_label2 = Label(search_Transaksi, text="       Check in").grid(row=2, column=2, sticky=W, padx=10)
			check_out_label2 = Label(search_Transaksi, text="Check out").grid(row=2, column=3, sticky=W, padx=10)
			for index, x in enumerate(result):
				num = 0
				index += 2
				for y in x:
					searched_label = Label(search_Transaksi, text=y)
					searched_label.grid(row=index+1, column=num)
					num +=1
			 
			csv_button = Button(search_Transaksi, text="Save to Excel", command=lambda: write_to_csv(result))
			csv_button.grid(row=index+2, column=0)

		#searched_label = Label(search Transaksi, text=result)
		#searched_label.grid(row=3, column=0, padx=10, columnspan=2)
		

	# Entry box to search for customer
	search_box = Entry(search_Transaksi)
	search_box.grid(row=0, column=1, padx=10, pady=10)
	# Entry box Label search for customer
	search_box_label = Label(search_Transaksi, text="Search Transaksi ")
	search_box_label.grid(row=0, column=0, padx=10, pady=10)
	# Entry box search  Button for customer
	search_button = Button(search_Transaksi, text="Search Transaksi", command=search_now)
	search_button.grid(row=1, column=0, padx=10)

#	searched_label = Label(search_Transaksi, text=y)
#	searched_label.grid(row=index, column=num)

	# Drop Down Box
	drop = ttk.Combobox(search_Transaksi, value=["Search by...", "Booking","Check in", "Check out", "No transaksi"])
	drop.current(0)
	drop.grid(row=0, column=2)
	
def hapus_Transaksi():
	hapus_Transaksi = Tk()
	hapus_Transaksi.title("Hapus Transaksi")
	hapus_Transaksi.geometry("400x300")

	id_label2 = Label(hapus_Transaksi,text="No transaksi : ")
	id_label2.grid(row=1,column=0,pady=10)

	id_box2 = Entry(hapus_Transaksi)
	id_box2.grid(row=1, column=1,pady=10)

	def hapus_now():
		delete = id_box2.get()
		sql = """DELETE FROM Transaksi WHERE no_transaksi =%s"""
		name = (delete, )
		my_cursor.execute(sql, name)
		mydb.commit()
		hapus_Transaksi.destroy()

	id_button = Button(hapus_Transaksi,text="Hapus",command=hapus_now)
	id_button.grid(row=2, column=0,columnspan=2)

# List Cusomters 
def list_Transaksi():
	list_Transaksi_query = Tk()
	list_Transaksi_query.title("List Semua Transaksi")
	list_Transaksi_query.geometry("800x600")
	no_transaksi_label2 = Label(list_Transaksi_query, text="    No transaksi").grid(row=0, column=0, sticky=W, padx=10)
	booking_label2 = Label(list_Transaksi_query, text="Booking ").grid(row=0, column=1, sticky=W, padx=10)
	check_in_label2 = Label(list_Transaksi_query, text="Check in").grid(row=0, column=2, sticky=W, padx=10)
	check_out_label2 = Label(list_Transaksi_query, text="Check out").grid(row=0, column=3, sticky=W, padx=10)

	# Query The Database
	my_cursor.execute("SELECT * FROM Transaksi")
	result = my_cursor.fetchall()
	
	for index, x in enumerate(result):
		num = 0
		for y in x:
			lookup_label = Label(list_Transaksi_query, text=y)
			lookup_label.grid(row=index+1, column=num)
			num +=1
	csv_button = Button(list_Transaksi_query, text="Save to Excel", command=lambda: write_to_csv(result))
	csv_button.grid(row=index+2, column=0)
# Create a Label
title_label = Label(root, text="Database Transaksi", font=("Helvetica", 16))
title_label.grid(row=0, column=0, columnspan=2, pady=10)

#Create Main Form To Enter Train Data
no_transaksi_label = Label(root, text="No Transaksi").grid(row=1, column=0, sticky=W, padx=10)
booking_label = Label(root, text="Booking ").grid(row=2, column=0, sticky=W, padx=10)
check_in_label = Label(root, text="Check_in").grid(row=3, column=0, sticky=W, padx=10)
check_out_label = Label(root, text="Check_out").grid(row=4, column=0, sticky=W, padx=10)

# Create Entry Boxes
no_transaksi_box = Entry(root)
no_transaksi_box.grid(row=1, column=1)

booking_box = Entry(root)
booking_box.grid(row=2, column=1, pady=5)

check_in_box = Entry(root)
check_in_box.grid(row=3, column=1, pady=5)

check_out_box = Entry(root)
check_out_box.grid(row=4, column=1, pady=5)

# Create Buttons
add_Transaksi_button = Button(root, text="Tambah Transaksi", command=add_Transaksi)
add_Transaksi_button.grid(row=6, column=0, padx=10, pady=10)

clear_fields_button = Button(root, text="Clear Fields", command=clear_fields)
clear_fields_button.grid(row=6, column=1)
# List Transaksi button
list_Transaksi_button = Button(root, text="List Transaksi", command=list_Transaksi)
list_Transaksi_button.grid(row=7, column=0, sticky=W, padx=10)	
# Search Transaksi
search_Transaksi_button = Button(root, text="Search Transaksi", command=search_Transaksi)
search_Transaksi_button.grid(row=7, column=1, sticky=W, padx=10)
# Edit Transaksi
edit_Transaksi_button = Button(root, text="Edit Transaksi", command=edit_Transaksi)
edit_Transaksi_button.grid(row=8, column=0, sticky=W, padx=10, pady=10)

hapus_Transaksi_button = Button(root, text="Hapus Transaksi", command=hapus_Transaksi)
hapus_Transaksi_button.grid(row=8, column=1, sticky=W, padx=10, pady=10)

root.mainloop()
