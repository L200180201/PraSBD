from tkinter import *
import mysql.connector
import csv
from tkinter import ttk

root = Tk()
root.title('PERHOTELAN')
root.geometry('450x380')

#Connect ke DB MySQL
mydb = mysql.connector.connect(
				user='root', 
				database='perhotelan'
			)

# Check to see if connection to MySQL was created
# print(mydb)

# Create a cursor and initialize it
my_cursor = mydb.cursor()

# Clear Text Fields
def clear_fields():
	id_Tamu_box.delete(0, END)
	nama_Tamu_box.delete(0, END)
	alamat_box.delete(0, END)

# Submit Tamu To Database
def add_Tamu():
	sql_command = "INSERT INTO Tamu (id_Tamu, nama_Tamu, alamat_tamu) VALUES (%s, %s, %s)"
	values = (id_Tamu_box.get(), nama_Tamu_box.get(), alamat_box.get())
	my_cursor.execute(sql_command, values)

	# Commit the changes to the database
	mydb.commit()
	# Clear the fields
	clear_fields()

# Write To CSV Excel Function
def write_to_csv(result):
	with open('Tamu.csv', 'a', newline='') as f:
		w = csv.writer(f, dialect='excel')
		for record in result:
			w.writerow(record)

# Edit Tamu
def edit_Tamu():
	edit_Tamu = Tk()
	edit_Tamu.title("Edit Tamu")
	edit_Tamu.geometry("1000x600")

	def update():
		
		sql_command = """UPDATE Tamu SET nama_Tamu = %s, alamat_tamu = %s WHERE id_Tamu = %s""" 

		nama_Tamu = nama_Tamu_box1.get()
		alamat = alamat_box1.get()
		id_Tamu = id_Tamu_box1.get()

		input = (nama_Tamu, alamat,id_Tamu)
		my_cursor.execute(sql_command, input)

		# Commit the changes to the database
		mydb.commit()
		# Clear the fields
		edit_Tamu.destroy()
		
	def edit_now(id, index):
		sql2 = "SELECT * FROM Tamu WHERE id_Tamu = %s"
		name2 = (id, )
		results = my_cursor.execute(sql2, name2)
		results = my_cursor.fetchall()
		print(results)

		#fart = Label(edit_Tamu, text=id)
		#fart.grid(row=10, column=1)
		#Create Main Form To Enter Customer Data
		id_Tamu_label = Label(edit_Tamu, text="ID").grid(row=index+2, column=0, sticky=W, padx=10)
		nama_Tamu_label = Label(edit_Tamu, text="Nama").grid(row=index+3, column=0, sticky=W, padx=10)
		alamat_label = Label(edit_Tamu, text="Alamat").grid(row=index+4, column=0, sticky=W, padx=10)

		global id_Tamu_box1
		id_Tamu_box1 = Entry(edit_Tamu)
		id_Tamu_box1.insert(0, results[0][0])
		id_Tamu_box1.grid(row=index+2, column=1)

		global nama_Tamu_box1
		nama_Tamu_box1 = Entry(edit_Tamu)
		nama_Tamu_box1.grid(row=index+3, column=1, pady=5)
		nama_Tamu_box1.insert(0, results[0][1])

		global alamat_box1
		alamat_box1 = Entry(edit_Tamu)
		alamat_box1.grid(row=index+4, column=1, pady=5)
		alamat_box1.insert(0, results[0][2])

		edit_record = Button(edit_Tamu, text="Save Record", command=update)
		edit_record.grid(row=index+6, column=0, padx=10)
		
	def search_now():
		selected = drop.get()
		sql = ""
		if selected == "Search by...":
			test = Label(edit_Tamu, text="Hey! Kamu Lupa memilih drop down selection")
			test.grid(row=2, column=0)
		if selected == "Nama":
			sql = "SELECT * FROM Tamu WHERE nama_Tamu = %s"
			
		if selected == "Alamat":
			sql = "SELECT * FROM Tamu WHERE alamat = %s"
			
		if selected == "ID Tamu":
			sql = "SELECT * FROM Tamu WHERE id_Tamu = %s"
			
		searched = search_box.get()
		#sql = "SELECT * FROM Tamu WHERE last_name = %s"
		name = (searched, )
		result = my_cursor.execute(sql, name)
		result = my_cursor.fetchall()

		if not result: 
			result = "Record Not Found..."
			searched_label = Label(edit_Tamu, text=result)
			searched_label.grid(row=2, column=0)

		else:
			id_label2 = Label(edit_Tamu, text="             ID Tamu").grid(row=2, column=1, sticky=W, padx=10)
			nama_label2 = Label(edit_Tamu, text="              Nama").grid(row=2, column=2, sticky=W, padx=10)
			alamat_label2 = Label(edit_Tamu, text="Alamat").grid(row=2, column=3, sticky=W, padx=10)
			for index, x in enumerate(result):
				num = 0
				index += 2
				stuff = str(x[0])
				edit_button = Button(edit_Tamu, text="Edit " + stuff, command=lambda: edit_now(stuff, index))
				edit_button.grid(row=index+1, column=num)
				for y in x:
					searched_label = Label(edit_Tamu, text=y)
					searched_label.grid(row=index+1, column=num+1)
					num +=1
			 
			
	# Entry box to search for customer
	search_box = Entry(edit_Tamu)
	search_box.grid(row=0, column=1, padx=10, pady=10)
	# Entry box Label search for customer
	search_box_label = Label(edit_Tamu, text="Search Tamu ")
	search_box_label.grid(row=0, column=0, padx=10, pady=10)
	# Entry box search  Button for customer
	search_button = Button(edit_Tamu, text="Search Tamu", command=search_now)
	search_button.grid(row=1, column=0, padx=10)
	# Drop Down Box
	drop = ttk.Combobox(edit_Tamu, value=["Search by...", "Nama","Alamat", "ID Tamu"])
	drop.current(0)
	drop.grid(row=0, column=2)


# Search Tamu
def search_Tamu():
	search_Tamu = Tk()
	search_Tamu.title("Search Tamu")
	search_Tamu.geometry("1000x600")

	def search_now():
		selected = drop.get()
		sql = ""
		if selected == "Search by...":
			test = Label(search_Tamu, text="Hey! Kamu Lupa memilih drop down selection")
			test.grid(row=2, column=0)
		if selected == "Nama":
			sql = "SELECT * FROM Tamu WHERE nama_Tamu = %s"
			
		if selected == "Alamat":
			sql = "SELECT * FROM Tamu WHERE alamat = %s"

		if selected == "ID Tamu":
			sql = "SELECT * FROM Tamu WHERE id_Tamu = %s"
			
		
		searched = search_box.get()
		#sql = "SELECT * FROM Tamu WHERE last_name = %s"
		name = (searched, )
		result = my_cursor.execute(sql, name)
		result = my_cursor.fetchall()

		if not result: 
			result = "Record Not Found..."
			searched_label = Label(search_Tamu, text=result)
			searched_label.grid(row=2, column=0)

		else:
			id_label2 = Label(search_Tamu, text="    ID Tamu").grid(row=2, column=0, sticky=W, padx=10)
			nama_label2 = Label(search_Tamu, text="              Nama").grid(row=2, column=1, sticky=W, padx=10)
			alamat_label2 = Label(search_Tamu, text="       Alamat").grid(row=2, column=2, sticky=W, padx=10)
		
			for index, x in enumerate(result):
				num = 0
				index += 2
				for y in x:
					searched_label = Label(search_Tamu, text=y)
					searched_label.grid(row=index+1, column=num)
					num +=1
			 
			csv_button = Button(search_Tamu, text="Save to Excel", command=lambda: write_to_csv(result))
			csv_button.grid(row=index+2, column=0)

		#searched_label = Label(search Tamu, text=result)
		#searched_label.grid(row=3, column=0, padx=10, columnspan=2)
		

	# Entry box to search for customer
	search_box = Entry(search_Tamu)
	search_box.grid(row=0, column=1, padx=10, pady=10)
	# Entry box Label search for customer
	search_box_label = Label(search_Tamu, text="Search Tamu ")
	search_box_label.grid(row=0, column=0, padx=10, pady=10)
	# Entry box search  Button for customer
	search_button = Button(search_Tamu, text="Search Tamu", command=search_now)
	search_button.grid(row=1, column=0, padx=10)

#	searched_label = Label(search_Tamu, text=y)
#	searched_label.grid(row=index, column=num)

	# Drop Down Box
	drop = ttk.Combobox(search_Tamu, value=["Search by...", "Nama","Alamat", "ID Tamu"])
	drop.current(0)
	drop.grid(row=0, column=2)
	
def hapus_Tamu():
	hapus_Tamu = Tk()
	hapus_Tamu.title("Hapus Tamu")
	hapus_Tamu.geometry("400x300")

	id_label2 = Label(hapus_Tamu,text="ID Tamu : ")
	id_label2.grid(row=1,column=0,pady=10)

	id_box2 = Entry(hapus_Tamu)
	id_box2.grid(row=1, column=1,pady=10)

	def hapus_now():
		delete = id_box2.get()
		sql = """DELETE FROM Tamu WHERE id_Tamu =%s"""
		name = (delete, )
		my_cursor.execute(sql, name)
		mydb.commit()
		hapus_Tamu.destroy()

	id_button = Button(hapus_Tamu,text="Hapus",command=hapus_now)
	id_button.grid(row=2, column=0,columnspan=2)

# List Cusomters 
def list_Tamu():
	list_Tamu_query = Tk()
	list_Tamu_query.title("List Semua Tamu")
	list_Tamu_query.geometry("800x600")
	id_label2 = Label(list_Tamu_query, text="    ID Tamu").grid(row=0, column=0, sticky=W, padx=10)
	nama_label2 = Label(list_Tamu_query, text="Nama").grid(row=0, column=1, sticky=W, padx=10)
	alamat_label2 = Label(list_Tamu_query, text="Alamat").grid(row=0, column=2, sticky=W, padx=10)
	
	# Query The Database
	my_cursor.execute("SELECT * FROM Tamu")
	result = my_cursor.fetchall()
	
	for index, x in enumerate(result):
		num = 0
		for y in x:
			lookup_label = Label(list_Tamu_query, text=y)
			lookup_label.grid(row=index+1, column=num)
			num +=1
	csv_button = Button(list_Tamu_query, text="Save to Excel", command=lambda: write_to_csv(result))
	csv_button.grid(row=index+2, column=0)
# Create a Label
title_label = Label(root, text="Database Tamu", font=("Helvetica", 16))
title_label.grid(row=0, column=0, columnspan=2, pady=10)

#Create Main Form To Enter Train Data
id_Tamu_label = Label(root, text="ID").grid(row=1, column=0, sticky=W, padx=10)
nama_Tamu_label = Label(root, text="Nama").grid(row=2, column=0, sticky=W, padx=10)
alamat_label = Label(root, text="Alamat").grid(row=3, column=0, sticky=W, padx=10)

# Create Entry Boxes
id_Tamu_box = Entry(root)
id_Tamu_box.grid(row=1, column=1)

nama_Tamu_box = Entry(root)
nama_Tamu_box.grid(row=2, column=1, pady=5)

alamat_box = Entry(root)
alamat_box.grid(row=3, column=1, pady=5)

# Create Buttons
add_Tamu_button = Button(root, text="Tambah Tamu", command=add_Tamu)
add_Tamu_button.grid(row=6, column=0, padx=10, pady=10)

clear_fields_button = Button(root, text="Clear Fields", command=clear_fields)
clear_fields_button.grid(row=6, column=1)
# List Tamu button
list_Tamu_button = Button(root, text="List Tamu", command=list_Tamu)
list_Tamu_button.grid(row=7, column=0, sticky=W, padx=10)	
# Search Tamu
search_Tamu_button = Button(root, text="Cari Tamu", command=search_Tamu)
search_Tamu_button.grid(row=7, column=1, sticky=W, padx=10)
# Edit Tamu
edit_Tamu_button = Button(root, text="Edit Tamu", command=edit_Tamu)
edit_Tamu_button.grid(row=8, column=0, sticky=W, padx=10, pady=10)

hapus_Tamu_button = Button(root, text="Hapus Tamu", command=hapus_Tamu)
hapus_Tamu_button.grid(row=8, column=1, sticky=W, padx=10, pady=10)

root.mainloop()
